$(window).on("load", function () {
    $("#preloader").delay(600).fadeOut()
    $("body").css("overflow-y" , "scroll")
}), $(document).ready(function () {
    (new WOW).init(), $("body").scrollspy({
        target: "#nav",
        offset: $(window).height() / 2
    }), $("#nav .nav-collapse").on("click", function () {
        $("#nav").toggleClass("open")
    }), $(".has-dropdown a").on("click", function () {
        $(this).parent().toggleClass("open-drop")
    })
});
// slider
$(document).ready(function () {
    var owl = $('.owl-carousel-first');
    owl.owlCarousel({
        lazyLoad:true,
        rtl: true,
        nav: false,
        dots: true,
        loop: true,
        autoplay: true,
        autoplayHoverPause: true,
        animateOut: "fadeOut",
        responsive: {
            0: {
                items: 1,
            },
            600: {
                items: 1
            },
            1000: {
                items: 1
            }
        }
    })
});
// slider
$(document).ready(function () {
    var owl = $('.owl-carousel-second');
    owl.owlCarousel({
        lazyLoad:true,
        rtl: true,
        nav: false,
        dots: false,
        loop: true,
        autoplay: true,
        autoplayHoverPause: true,
        animateOut: "fadeOut",
        responsive: {
            0: {
                items: 1,
            },
            600: {
              items: 2,
            },
            800: {
                items: 3,
            },
            1200: {
                items: 4,
            }
        }
    })
});
// slider
$(document).ready(function () {
    var owl = $('.owl-carousel-three');
    owl.owlCarousel({
        lazyLoad:true,
        rtl: true,
        nav: true,
        dots: false,
        center: true,
        loop: true,
        autoplay: false,
        autoplayHoverPause: true,
        animateOut: "fadeOut",
        responsive: {
            0: {
                items: 1,
            },
            600: {
                items: 3
            },
            1000: {
              items: 4
            },
            1200: {
                items: 5
            }
        }
    })
});
// lazy load
lozad(".lozad", {
    load: function (o) {
        o.src = o.dataset.src, o.onload = function () {
            o.classList.add("show-lazy")
        }
    }
}).observe();
$(".nav__menu-item").on("click", function () {
    $(this).find(".nav__submenu").toggleClass("open")
});
$(document).ready(function () {
    // cartMenu
    $('.menu-wrapper').on('click', function () {
        $(".cart-menu").removeClass("cart-close");
        $('body').addClass('dis-overlay');
    });

    $('.close-btn').on('click', function () {
        $(".cart-menu").addClass("cart-close");
        $('.cart-menu').removeClass('in');
        $('body').removeClass('dis-overlay');
    });
});
// like
$('.like-click').click(function(){
    $(this).toggleClass('fa-heart');
    $(this).toggleClass('fa-heart-o');
});
// profile
$('.user-image').click(function(){
    $(".nav__submenu").toggleClass('display-b');
});

$(document).ready(function () {
    // show password
    $('.show-password').on('click', function () {
        var $inp1 = $(this).parent().find(".input-password");
        $inp1.attr('type') === 'password' ? $inp1.attr('type', 'text') : $inp1.attr('type', 'password');
    });

    // select
    $('.js-example-basic-single').select2();
});
// upload img
$(function () {
    var e = {
        init: function () {
            e.setPreviewImg(), e.listenInput()
        },
        setPreviewImg: function (s) {
            var o = $(s).val(),
                i = $(s).siblings(".file-upload-text");
            o ? (o = o.replace(/^C:\\fakepath\\/, ""), $(i).val(o), e.showPreview(s, o, i)) : $(i).val("")
        },
        showPreview: function (e, s, o) {
            var i = $(e)[0].files;
            if (i && i[0]) {
                var t = new FileReader;
                t.onload = function (i) {
                    var t = $(e).parents(".file-upload-wrapper").siblings(".preview"),
                        n = $(t).find("img");
                    0 === n.length ? $(t).html('<img src="' + i.target.result + '" alt=""/>') : n.attr("src", i.target.result), o.val(s), $.each($(".img-wrapper img"), function (e, s) {
                        var o = $(s).attr("src");
                        $(s).parent().css("background", "url(" + o + ") no-repeat center center").css("background-size", "cover"), $(s).remove()
                    })
                }, t.onloadstart = function () {
                    $(o).val("uploading..")
                }, t.readAsDataURL(i[0])
            }
        },
        listenInput: function () {
            $(".file-upload-native").on("change", function () {
                e.setPreviewImg(this)
            })
        }
    };
    e.init();

    // check all
    $('#select-all').click(function(event) {
        if(this.checked) {
            // Iterate each checkbox
            $(':checkbox').each(function() {
                this.checked = true;
            });
        } else {
            $(':checkbox').each(function() {
                this.checked = false;
            });
        }
    });

});
$(document).ready(function(){

    $('.input-edit button').click(function(){
        $(this).parent().find('input').attr('readonly', false);
        $(this).parent().find('input').attr('value', '');
    });

    // increase
    $('.add-btn').on('click', function () {
        var $qty1 = $(this).parent().parent().find('.prod-count-value');
        var currentVal = parseInt($qty1.val());
        if (!isNaN(currentVal)) {
            $qty1.val(currentVal + 1);
        }
    });

    // decrease
    $('.minuse-btn').on('click', function () {
        var $qty2 = $(this).parent().parent().find('.prod-count-value');
        var currentVal = parseInt($qty2.val());
        if (!isNaN(currentVal) && currentVal > 0) {
            $qty2.val(currentVal - 1);
        }
    });

    // form wizard
    $('.pay-form').bootstrapWizard();
    window.prettyPrint && prettyPrint()

    // product-details
    $('.product .slider .owl-carousel1').owlCarousel({
        items: 1,
        loop: true,
        URLhashListener: true,
        autoplayHoverPause: true,
        startPosition: 'URLHash',
        dots: false,
        nav: true,
        navText: ['<i class="fa fa-chevron-left"></i>', '<i class="fa fa-chevron-right"></i>'],
        smartSpeed: 2000,
        autoplay: true,
    });
    $('.owl-carousel2').owlCarousel({
        items: 4,
        loop: true,
        URLhashListener: true,
        autoplayHoverPause: true,
        startPosition: 'URLHash',
        dots: false,
        nav: false,
        smartSpeed: 2000,
        autoplay: true,
        margin: 10,
        responsive: {
            0: {
                items: 3,
            },
            600: {
                items: 4
            },
            1000: {
                items: 4
            },
            1200: {
                items: 4
            }
        }
    });
});
// filter
$(document).ready(function () {
    var min = document.getElementById("min-range").innerHTML,
        max = document.getElementById("max-range").innerHTML;
// range
    $("#range").ionRangeSlider({
        type: "double",
        min: min,
        max: max,
        from: 100,
        to: 15000,
        hide_from_to: false,
        grid: false
    });
});
$('.filter-click').click(function(){
    $(".filtter-collapse").toggle('show');
});
